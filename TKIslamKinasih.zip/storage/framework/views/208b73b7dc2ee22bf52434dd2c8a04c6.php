<style>
    .carousel-item img {
        border-radius: 20px;
        transition: transform 0.5s ease-in-out;
        object-fit: cover;
        height: 500px;
        width: 100%;
    }
    .carousel-inner {
        border-radius: 20px;
    }

    .lb-zoom {
      transform-origin: center center;
      transition: transform 0.2s ease-in-out;
    }

    .lb-zoom:hover {
      cursor: zoom-in;
    }
</style><?php /**PATH C:\xampp\htdocs\uazzzz\UAS-WebProg\resources\views\css_in_view\galeri_css.blade.php ENDPATH**/ ?>