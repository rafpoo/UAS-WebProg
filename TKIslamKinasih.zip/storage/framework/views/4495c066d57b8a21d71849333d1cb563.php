<style>
    .accordion-body {
        color: #000; 
    }
</style>
<?php /**PATH C:\xampp\htdocs\uazzzz\UAS-WebProg\resources\views\css_in_view\aktivitas_css.blade.php ENDPATH**/ ?>