<style>

</style><?php /**PATH C:\xampp\htdocs\uazzzz\UAS-WebProg\resources\views\css_in_view\welcome_css.blade.php ENDPATH**/ ?>