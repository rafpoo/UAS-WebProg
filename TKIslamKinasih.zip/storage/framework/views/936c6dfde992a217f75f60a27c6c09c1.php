<style>
    .card {
        background-color: #2D6A4F;
        border-radius: 20px;
        padding: 20px;
        color: white;
        text-align: center;
        margin: 20px;
    }
    .card img {
        border-radius: 15px;
        width: 100%;
        height: auto;
    }
</style><?php /**PATH C:\xampp\htdocs\uazzzz\UAS-WebProg\resources\views\css_in_view\acara_css.blade.php ENDPATH**/ ?>