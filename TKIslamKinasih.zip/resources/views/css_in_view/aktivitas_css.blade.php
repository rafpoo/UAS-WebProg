<style>
    .accordion-body {
        color: #000; 
    }
</style>
