<style>
    .card {
        background-color: #2D6A4F;
        border-radius: 20px;
        padding: 20px;
        color: white;
        text-align: center;
        margin: 20px;
    }
    .card img {
        border-radius: 15px;
        width: 100%;
        height: auto;
    }
</style>