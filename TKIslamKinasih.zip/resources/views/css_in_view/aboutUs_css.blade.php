<style>
    .welcome-section {
        padding: 50px 20px;
        text-align: center;

        border-radius: 10px;
        margin-top: 30px;
    }
    .img-TK {
        width: 100%;
        max-width: 750px;
        border-radius: 10px;
    }
</style>
